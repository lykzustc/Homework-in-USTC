    	
/**************************************************************************************************/
/* Copyright (C) lyk, SSE@USTC, 2014-2015                                                         */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  lyk                                                                  */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a interface of menu_operate                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by lyk, 2014/09/20
 *
 */


/*
 *you can add or remove any attributes of the struct
 * but the 'struct LinkTable *pNode'
 */
typedef struct DataNode
{
	struct LinkTableNode * pNext; 
	char*   cmd;
 	char*   desc;
 	int     (*handler)();
} tDataNode;

typedef struct LinkTableNode 
{ 
    struct LinkTableNode * pNext; 
} tLinkTableNode; 


typedef struct LinkTable 
{ 
	tLinkTableNode *pHead; 
	tLinkTableNode *pTail; 
	int			SumOfNode; 
/*	pthread_mutex_t mutex;*/ 
} tLinkTable; 

#define SUCCESS 1
#define FAILURE 0
tDataNode * InputYourCmd();

int ShowAllCmd();
/*init all resource that a new menu need*/
int InitNes();

/*find a cmd that you want*/
int MenuStart();

/*add a cmd that you need*/
int AddCmd();

/*delete the cmd that you needn't*/
int DeleteCmd();

