First     :    input "make"
Second    :    input "./menutest" or "./linktest"
Third     :    input "make clean"
