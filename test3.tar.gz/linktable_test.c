#include<stdio.h>
#include<stdlib.h>

#include"linktable.h"
#define Debug printf

int results[7] = {1,1,1,1,1,1,1};

char *info1[2] =
 {
    "is success!",
    "is failed!"
 };

 char *info[7] =
    {
        "CreateLinkTable",
        "DeleteLinkTable",
        "AddLinkTableNode",
        "DelLinkTableNode",
        "SearchLinkTableNode",
        "GetLinkTableHead",
        "GetNextLinkTableNode"
    }; 
     
tLinkTableNode * pNode  = NULL;
tLinkTableNode * pNode1 = NULL;
tLinkTableNode * pNode2 = NULL;
tLinkTableNode * pNode3 = NULL;
tLinkTableNode * pNode4 = NULL;
tLinkTableNode * pNode5 = NULL;
tLinkTableNode * pNode6 = NULL;

tLinkTable * p = NULL;

int ConditionStub(tLinkTableNode * pNode)
{
    if( pNode != NULL)
    {	
	return SUCCESS;
    }
    else
    {
    	return FAILURE;
    }
}

void CreateLinkTableTest()
{
	 if(p == NULL)
	 {
	 	results[0] = 0;
	 }
}

void DeleteLinkTableTest()
{
    int deleteLinkTable = 0;
    int deleteLinkTable1 = 0;
    
    deleteLinkTable = DeleteLinkTable(NULL);
    deleteLinkTable1 = DeleteLinkTable(p); 
    
    if(deleteLinkTable != FAILURE || deleteLinkTable1 != SUCCESS)
    {
        results[1] = 0;
    }  
    
    
}

void AddLinkTableNodeTest()
{
	 
    int addLinkTableNode = 0;
    int addLinkTableNode1 = 0;
    int addLinkTableNode2 = 0;
    int addLinkTableNode3 = 0;
    int addLinkTableNode4 = 0;
    
    addLinkTableNode = AddLinkTableNode(NULL,pNode);
    addLinkTableNode1 = AddLinkTableNode(p,NULL);
    addLinkTableNode2 = AddLinkTableNode(p,pNode);
    addLinkTableNode3 = AddLinkTableNode(p,pNode1);
    addLinkTableNode4 = AddLinkTableNode(p,pNode2);
    
    if(addLinkTableNode != FAILURE || addLinkTableNode1 != FAILURE||
       addLinkTableNode2 != SUCCESS || addLinkTableNode3 != SUCCESS||
       addLinkTableNode4 != SUCCESS)
    {
        results[2] = 0;
    }
}

void DelLinkTableNodeTest()
{
    int deleteLinkTableNode = 0;
    int deleteLinkTableNode1 = 0;
    int deleteLinkTableNode2 = 0;
    int deleteLinkTableNode3 = 0;
    int deleteLinkTableNode4 = 0;
    
    deleteLinkTableNode = DelLinkTableNode(p,NULL);
    deleteLinkTableNode1 = DelLinkTableNode(NULL,pNode);
    deleteLinkTableNode2 = DelLinkTableNode(p,pNode);
    deleteLinkTableNode3 = DelLinkTableNode(p,pNode2);  
        
    if(deleteLinkTableNode != FAILURE ||deleteLinkTableNode1 != FAILURE ||
       deleteLinkTableNode2 != SUCCESS ||deleteLinkTableNode3 != SUCCESS)
    {
        results[3] = 0;
    }
     
} 

void SearchLinkTableNodeTest()
{
    int (* condition)() = ConditionStub;
    pNode3 = SearchLinkTableNode(NULL, condition);
    pNode4 = SearchLinkTableNode(p, NULL);
    pNode5 = SearchLinkTableNode(p, condition);
    
    if(pNode3 != NULL || pNode4 != NULL ||pNode5 == NULL)
    {
       results[4] = 0;
    }
}
 
void GetLinkTableHeadTest()
{
    
    pNode3 = GetLinkTableHead(p); 
    pNode4 = GetLinkTableHead(NULL);
    pNode5 = GetLinkTableHead(p);
    
    if(pNode3 == NULL || pNode4 != NULL ||pNode5 == NULL)
    {
        results[5] = 0;
    }
	
}

void GetNextLinkTableNodeTest()
{
    pNode3 = GetNextLinkTableNode(p,pNode);
    pNode4 = GetNextLinkTableNode(p,NULL);
    pNode5 = GetNextLinkTableNode(NULL,pNode);
    pNode6 = GetNextLinkTableNode(p,pNode2);
    
    if(pNode3 == NULL || pNode4 != NULL ||pNode5 != NULL ||pNode6 != NULL)
    {
        results[6] = 0;
    }
} 
void linktable_test();

int main(void)
{
    linktable_test();
};

void linktable_test()
{
    int i;
    pNode = (tLinkTableNode *)malloc(sizeof(tLinkTableNode));
    pNode1 = (tLinkTableNode *)malloc(sizeof(tLinkTableNode));
    pNode2 = (tLinkTableNode *)malloc(sizeof(tLinkTableNode));
    p = CreateLinkTable();
    
    if(pNode == NULL || pNode1 == NULL || pNode2 == NULL)
    {
        Debug("create linktablenode fail,test cannot continue!\n");
        exit(0);
    }
    if(p == NULL)
    {
        Debug("the CreateLinkTable function fail,test cannot continue!\n");
        exit(0);
    }   
    
    CreateLinkTableTest();
    AddLinkTableNodeTest();
    SearchLinkTableNodeTest();
    GetNextLinkTableNodeTest(); 
    GetLinkTableHeadTest();
    DelLinkTableNodeTest();
    DeleteLinkTableTest();
    
    for( i = 0; i < 7; i++)
    {
    	if(results[i] == 0)
    	{
    		printf("%s %s\n",info[i],info1[1]);
    	}
    	else

    	{
    		printf("%s %s\n",info[i],info1[0]);
    	}
    }
}
