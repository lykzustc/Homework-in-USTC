/**************************************************************************************************/
/* Copyright (C) Lyk, SSE@USTC, 2014-2015                                                         */
/*                                                                                                */
/*  FILE NAME             :  Lykmenu.c                                                            */
/*  PRINCIPAL AUTHOR      :  Lyk                                                                  */
/*  SUBSYSTEM NAME        :  menu.c                                                               */
/*  MODULE NAME           :  menu.c                                                               */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/12                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Lyk, 2014/09/23
 *
 */
 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "menu.h"
#include "linktable.h"

 
#define CMD_MAX_LEN 128
#define DESC_MAX_LEN 1200

tLinkTable * pLinkTable = NULL; 

int Help()
{
    printf("%s %s\n",((tDataNode*)GetLinkTableHead(pLinkTable)) -> cmd,
                     ((tDataNode*)GetLinkTableHead(pLinkTable)) -> desc);
    ShowAllCmd();
    return 0;
}

tDataNode * InitDataNode()
{
    tDataNode *pDataNode;
    pDataNode = (tDataNode*)malloc(sizeof(tDataNode));
    if(pDataNode == NULL)
    {
        exit(0);
    }
    return pDataNode;
}

tLinkTableNode * CheckCmd(char* cmd,tLinkTable* pLinkTable)
{
    tDataNode *p = (tDataNode *)GetLinkTableHead(pLinkTable);
    while(p != NULL)
    {
        if(strcmp(cmd,p->cmd) == 0)
        {
            return (tLinkTableNode*)p;
        }
        p = (tDataNode *)(p->pNext);
    }
    return NULL;
}



tDataNode* FindCmd(char *cmd)
{
    if( pLinkTable -> pHead == NULL || cmd == NULL )
    {
        return NULL;
    }
    tDataNode * pDataNode =(tDataNode *)pLinkTable -> pHead;
    while( pDataNode != NULL )
    {
        if( !strcmp( pDataNode -> cmd, cmd ) )
        {
            return pDataNode;
        }
        pDataNode = (tDataNode *)pDataNode -> pNext;
    }
    return NULL;
}

void InitLinkTable()
{
    pLinkTable = CreateLinkTable(); 
    if(pLinkTable == NULL)
    {
        exit(0);
    }
}

void InitCmdList()
{
    tDataNode * pDataNode = InitDataNode();
    pDataNode->pNext = NULL;
    pDataNode->cmd = "help";
    pDataNode->desc = "This is help menu";
    pDataNode->handler = Help;
    tLinkTableNode* pLinkTableNode = (tLinkTableNode *)pDataNode;
    AddLinkTableNode(pLinkTable,pLinkTableNode);        
}

void InitNes()
{
    InitLinkTable();
    InitCmdList();
}

tDataNode * InputYourCmd()
{
    int i;
    tDataNode * pDataNode = InitDataNode();
    pDataNode -> cmd = (char *)malloc(sizeof(char));
    pDataNode->pNext = NULL;
    printf("please input your cmd\n");
    scanf("%s",pDataNode -> cmd);
    while(CheckCmd(pDataNode -> cmd,pLinkTable))
    {
        printf("repeat!please reinput\n");
        scanf("%s",pDataNode -> cmd);
    }
    printf("please input the description of your cmd\n");
    pDataNode -> desc = (char *)malloc(sizeof(char)*DESC_MAX_LEN);
    getchar();
    fgets( pDataNode -> desc,DESC_MAX_LEN,stdin);
    i = strlen(pDataNode -> desc);
    (pDataNode -> desc)[i-1] = '\0';
     pDataNode ->handler = NULL;
    return pDataNode;
    
}

int ShowAllCmd()
{
    printf("cmd list:\n");
    tDataNode *p = (tDataNode *)GetLinkTableHead(pLinkTable);
    while( p != NULL)
    {
        printf("%s %s\n",p -> cmd,p -> desc);
        p = (tDataNode *)(p -> pNext);
    }	
    return 0;
}

/* add client's cmd and smd's description */
int AddCmd()
{
    tLinkTableNode * pLinkTableNode = (tLinkTableNode *)InputYourCmd();
    if(pLinkTableNode == NULL)
    {
        return 0;
    }
    else
    {
        AddLinkTableNode(pLinkTable,pLinkTableNode); 
        printf("SUCESS!\n");
    }
    return 1;
}

/* delete a cmd of yours*/
int DeleteCmd()
{
    char * cmd;
    tLinkTableNode * pLinkTableNode;   
    printf("please input the cmd that you want to delete\n");
    cmd = (char *)malloc(sizeof(char));
    scanf("%s",cmd);
    pLinkTableNode = CheckCmd(cmd,pLinkTable);
    if(pLinkTableNode != NULL)
    {
        DelLinkTableNode(pLinkTable,pLinkTableNode);
        printf("Delete!\n");
        return 1;
    }
    printf("cmd not exist!\n");
    return 0;
}

/*find a cmd*/
int MenuStart()
{
    tDataNode* p;
    char cmd[CMD_MAX_LEN];
    printf("Intput a cmd >");
    scanf("%s", cmd);
    p = FindCmd(cmd);	
    if(p)
    {
        if(p -> handler )
        {
            p -> handler();
        }
        else
        {
            printf("%s %s\n",p -> cmd,p -> desc);
        }
    }
    else
    {
        printf("This is a wrong cmd\n");
    }
 }
 
