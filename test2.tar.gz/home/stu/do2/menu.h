/**************************************************************************************************/
/* Copyright (C) Lyk, SSE@USTC, 2014-2015                                                         */
/*                                                                                                */
/*  FILE NAME             :  Lykmenu.h                                                            */
/*  PRINCIPAL AUTHOR      :  Lyk                                                                  */
/*  SUBSYSTEM NAME        :  menu.h                                                               */
/*  MODULE NAME           :  menu.h                                                               */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/12                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Lyk, 2014/09/23
 *
 */
 

/*
 *you can add or remove any attributes of the struct
 * except the 'struct LinkTableNode *pNext'
 */
typedef struct DataNode
{
	struct LinkTableNode * pNext; 
	char*   cmd;
 	char*   desc;
 	int     (*handler)();
} tDataNode;

tDataNode * InputYourCmd();

int ShowAllCmd();
/*init all resource that a new menu need*/
void InitNes();

/*find a cmd that you want*/
int MenuStart();

/*add a cmd that you need*/
int AddCmd();

/*delete the cmd that you needn't*/
int DeleteCmd();

void InitLinkTable();
 
void InitCmdList();

int Help();

tDataNode * InitDataNode();



int ShowAllCmd();
tDataNode* FindCmd(char *cmd);

